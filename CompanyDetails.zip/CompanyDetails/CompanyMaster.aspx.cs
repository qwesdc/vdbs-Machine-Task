﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace CompanyDetails
{
    public partial class CompanyMaster : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=lenovosqlexpress;Initial Catalog=CompanyDB;Integrated Security=True");
            con.Open();
            SqlCommand comm = new SqlCommand("INSERT INTO CompanyMaster VALUES('"+txtName.Text+"')",con );
            comm.ExecuteNonQuery();
            con.Close();
           
           // ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert("Successfully Inserted")");
        }

      

        protected void btnUpload_Click(object sender, EventArgs e)
        {

            if (FileUpload1.HasFile) 
                try
                {
                    FileUpload1.SaveAs("E:\\" + FileUpload1.FileName);         
                    lblMessage.Text = "File Uploaded Sucessfully !! ";
                }
                catch (Exception ex)
                {
                    lblMessage.Text = "File Not Uploaded!!" + ex.Message.ToString();
                }
            else
            {
                lblMessage.Text = "Please Select File and Upload Again";

            }

        }
    }
}